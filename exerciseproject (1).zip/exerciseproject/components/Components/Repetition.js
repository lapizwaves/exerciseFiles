import React, { useState } from 'react';
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';

export default function Repetition() {
  const [reps, setReps] = useState(0);
  const [sets, setSets] = useState(0);

  // Increase repetitions
  const increaseReps = () => {
    setReps(reps + 1);
  };

  // Decrease repetitions
  const decreaseReps = () => {
    if (reps > 0) {
      setReps(reps - 1);
    }
  };

  // Increase sets
  const increaseSets = () => {
    setSets(sets + 1);
  };

  // Decrease sets
  const decreaseSets = () => {
    if (sets > 0) {
      setSets(sets - 1); // Decreases sets count
    }
  };

  return (
    <View style={styles.container}>
      {/* Repetitions Section */}
      <View style={styles.repetitionContainer}>
        <Text style={styles.label}>Repetitions:</Text>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.arrowButton} onPress={decreaseReps}>
            <Text style={styles.arrowText}>↓</Text>
          </TouchableOpacity>

          <Text style={styles.countText}>{reps}</Text>

          <TouchableOpacity style={styles.arrowButton} onPress={increaseReps}>
            <Text style={styles.arrowText}>↑</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Sets Section */}
      <View style={styles.repetitionContainer}>
        <Text style={styles.label}>Sets:</Text>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.arrowButton} onPress={decreaseSets}>
            <Text style={styles.arrowText}>↓</Text>
          </TouchableOpacity>

          <Text style={styles.countText}>{sets}</Text>

          <TouchableOpacity style={styles.arrowButton} onPress={increaseSets}>
            <Text style={styles.arrowText}>↑</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  repetitionContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  buttonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    width: '80%', // Adjust the width for a better layout
  },
  arrowButton: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
    marginHorizontal: 10,
  },
  arrowText: {
    color: 'white',
    fontSize: 20,
  },
  countText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
});
