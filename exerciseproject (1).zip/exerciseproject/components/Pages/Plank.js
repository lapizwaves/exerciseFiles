import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import Duration from '../Components/Duration';

export default function PlankPage({ setCurrentPage }) {
  return (
    <View style={styles.page}>
      <TouchableOpacity style={styles.btn} onPress={() => setCurrentPage('home')}>
        <Text style={styles.btnText}>Home</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.btn} onPress={() => setCurrentPage('running')}>
        <Text style={styles.btnText}>Suggested Running</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.btn} onPress={() => setCurrentPage('pushup')}>
        <Text style={styles.btnText}>Pushup</Text>
      </TouchableOpacity>
      <Text style={styles.text}>Plank Page</Text>

      <Duration/>
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  btn: {
    padding: 10,
    backgroundColor: 'green',
    marginBottom: 10,
    borderRadius: 5,
    alignItems: 'center',
    width: 100,
    display: 'flex',
    marginHorizontal: 5,
  },
  btnText: {
    color: 'white',
  },
  text: {
    fontSize: 24,
  },
});
