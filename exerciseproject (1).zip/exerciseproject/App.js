// App.js
import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import HomePage from './components/Pages/Home';
import PlankPage from './components/Pages/Plank';
import PushupPage from './components/Pages/Pushup';
import RunningPage from './components/Pages/Running';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');

  // Render the corresponding page based on currentPage state
  const renderPage = () => {
    switch (currentPage) {
      case 'plank':
        return <PlankPage setCurrentPage={setCurrentPage} />;
      case 'pushup':
        return <PushupPage setCurrentPage={setCurrentPage} />;
      case 'running':
        return <RunningPage setCurrentPage={setCurrentPage} />;
      default:
        return <HomePage setCurrentPage={setCurrentPage} />;
    }
  };

  return <View style={styles.container}>{renderPage()}</View>;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
});
